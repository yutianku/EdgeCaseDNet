import warnings
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1' # 下面老是报错 shape 不一致


os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
warnings.filterwarnings('ignore')

# from ultralytics import YOLO
from ultralytics.models import RTDETR

if __name__ == '__main__':
    #  主干 yolov8-MobileNetv4.yaml
    # 注意力  yolov8-MLCA.yaml  yolov8-MobileNetv4-MLCA.yaml
    # 检测头 yolov8-AFPN.yaml  yolov8-MobileNetv4-AFPN.yaml
    # 主干+注意力+检测头 yolov8-MMA.yaml

    model = RTDETR(model='ultralytics/cfg/models/rt-detr/rt-detr-test.yaml')
    # model = YOLO('ultralytics/cfg/models/v8/yolov8-HGNet.yaml').load('yolov8n.pt')
    #model = YOLO('ultralytics/cfg/models/v8/yolov8.yaml').load('yolov8n.pt')

    model.train(data='ultralytics/cfg/data.yaml',
                cache=False,
                imgsz=640,
                epochs=100,
                batch=32,
                close_mosaic=10,
                workers=8,
                # device="0，1",
                # optimizer='SGD', # using SGD
                optimizer='AdamW', # using

                # resume='', # last.pt path
                # amp=False # close amp
                # fraction=0.2,
                project='runs/train',
                name='exp',
                )
    model.export(format='onnx')  # dynamic=True



