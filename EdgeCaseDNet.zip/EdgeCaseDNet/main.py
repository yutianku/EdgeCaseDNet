import os.path
import shutil
import cv2
import snakeviz
import time
from read import main as txt_read_main
from picture_cut import main as picture_cut_main
# from number_detect import getmaxnumber
from detect_pointer import main as detect_pointer_main
from convert import main as convert_main
from km_read import main as km_read
import number_read
from convert_center import main as convert_center_main

from template_gear import template_gear

import numpy as np
import torch
from ultralytics import YOLO

if __name__ == '__main__':

    # delete dictory
    if os.path.exists('./img_out'):
        shutil.rmtree('./img_out')
    else:
        pass
    if os.path.exists('./img_crop'):
        shutil.rmtree('./img_crop')
    else:
        pass
    # 仪表盘识别
    d_model = YOLO('models/YOLOV8X-V5.onnx')
    n_model = YOLO('models/yolov8-number.pt')
    # 保存txt
    d_model.predict(source='img_test/',save=True, name='predict', show=False, save_conf=True, save_txt=True,save_crop=True)

    n_model.predict(source='img_out/crops/digitalinstrument', save=True,show=False, save_conf=True,save_txt=True ,save_dir = 'img_crop/')

    i = 1

    while i <= 50:
        start_total = time.time()
        # 读取txt和原来输入的图img0
        detections ,img0= txt_read_main(num=i)
        # 仪表盘切割
        cut1, cut2, cut3= picture_cut_main(num=i)
        # 读取仪表盘数字
        s1, s2 = number_read.main(i)

        # 检查s1是否为None
        if s1 is None:
            # 对原始图像进行处理，得到处理后的指针斜率
            k1, k2 = km_read(img0, detections)


        # 获取仪表指针占比
        ratio1, ratio2 = detect_pointer_main(i, cut1, cut2,detections,k1,k2)


        # 仪表数字计算
        num1 = 8 * ratio1
        num2 = 200 * ratio2
        if num2 <= 10:
            num2 = 0

        end_total = time.time()
        # 输出数据
        print('---------------——————————--' + str(i) + '---------------——————————————--')

        if s1 is None:

             print('刻度仪表盘1:', np.round(num1), '\t', '刻度仪表盘2:', np.round(num2),)
        else:
            print('转速为：', s1, 'R/MIN', '\t', '车速为：', s2, 'KM/H', '\t')

        print('识别用时：',end_total - start_total)
        i = i + 1
        print('-------------------------——————————————————-----------------------')








