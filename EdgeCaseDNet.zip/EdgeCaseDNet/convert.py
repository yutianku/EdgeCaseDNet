# -*- coding: utf-8 -*-
import os
from PIL import Image
import cv2
import numpy

def RGB2BlackWhite(img):
    img_resize = cv2.resize(img, None, fx=0.5, fy=0.5)
    im = Image.fromarray(cv2.cvtColor(img_resize, cv2.COLOR_BGR2RGB))
    #print(im)
    #print("image info,", im.format, im.mode, im.size)
    (w, h) = im.size
    R = 0
    G = 0
    B = 0

    for x in range(w):
        for y in range(h):
            pos = (x, y)
            rgb = im.getpixel(pos)
            (r, g, b) = rgb
            R = R + r
            G = G + g
            B = B + b

    rate1 = R * 1000 / (R + G + B)
    rate2 = G * 1000 / (R + G + B)
    rate3 = B * 1000 / (R + G + B)

    #print("rate:", rate1, rate2, rate3)

    for x in range(w):
        for y in range(h):
            pos = (x, y)
            rgb = im.getpixel(pos)
            (r, g, b) = rgb
            n = r * rate1 / 1000 + g * rate2 / 1000 + b * rate3 / 1000
            # print "n:",n
            if n >= 210:
                im.putpixel(pos, (0, 0, 0))
            else:
                im.putpixel(pos, (255, 255, 255))


    img1 = cv2.cvtColor(numpy.asarray(im), cv2.COLOR_RGB2BGR)
    return img1


def main(img1, img2):
    return RGB2BlackWhite(img1), RGB2BlackWhite(img2)
    #print(str(2 * i) + '.jpg')



if __name__ == '__main__':
    '''i = 1
    while i <= 36:
        main(i)
        i += 1'''

