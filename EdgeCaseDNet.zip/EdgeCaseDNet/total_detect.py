import time

import pytesseract
import cv2


def gettotal(img):
    config_speed = r'-c tessedit_char_whitelist=0123456789 --psm 11 --oem 3'         # 5(29)/6(9)/11(6)/12(10)
    config_gear = r'-c tessedit_char_whitelist=NDPR --psm 11 --oem 3'

    # 获取图片长宽
    h, w= img.shape[0:2]
    img_speed = img[15:h//3-10, 0:2*w//3+10]
    #img_speed = cv2.resize(img_speed, None, fx=1.2, fy=1.2)     # 0.8(14)/0.5(13)/0.6(12)
    #cv2.imshow('speed.jpg', img_speed)
    img_gear = img[2 * h//3-15:h-20, 0:w]
    #img_gear = cv2.resize(img_gear, None, fx=1.2, fy=1.2)
    #cv2.imshow('gear.jpg', img_gear)
    cv2.imwrite('P.jpg', img_gear)
    #cv2.waitKey(0)
    #start = time.time()
    s1 = pytesseract.image_to_string(img_speed, config=config_speed)
    s2 = pytesseract.image_to_string(img_gear, config=config_gear)
    #end = time.time()
    #print(end - start)

    # speed
    slist1 = s1.split("\n")
    #print(i,'====================================================')
    maxspeed = 0
    for item in slist1:
        if len(item) >= 4:
            slist1.remove(item)
        if item == '':
            slist1.remove(item)
    #maxspeed = max(slist1)
    for item in slist1:
        if int(item) > maxspeed:
            maxspeed = int(item)

    # gear
    slist2 = s2.split("\n")

    for item in slist2:
        if len(item) >= 2:
            slist2.remove(item)
        if item == '':
            slist2.remove(item)

    for item in slist2:
        if item == 'D':
            return item, maxspeed
        if item == 'P':
            return item, maxspeed
        if item == 'R':
            return item, maxspeed
        if item == 'N':
            return item, maxspeed

    '''for item in slist2:
        if item == 'D':
            global D
            D = False
            return item, maxspeed
        else:
            D = True
    for item in slist2:
        if D & (item == 'P'):
            global P
            P = False
            return item, maxspeed
        else:
            P = True
    for item in slist2:
        if D & P & (item == 'R'):
            global R
            R = False
            return item, maxspeed
        else:
            R = True
    for item in slist2:
        if D & P & R & (item == 'N'):
            return item, maxspeed'''
    

    return "None", maxspeed




