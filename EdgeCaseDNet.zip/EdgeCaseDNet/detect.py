import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r'E:\SC\Yolov8\models/yolov8-HGNET-best.pt') # select your model.pt path
    model.predict(source=r'E:\SC\Yolov8\Dataset\soda\images\test',
                  imgsz=640,
                  project='runs/detect',
                  name='exp',
                  save=True,
                #   visualize=True # visualize model features maps
                )