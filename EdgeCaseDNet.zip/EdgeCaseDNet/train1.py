import warnings
import os

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
warnings.filterwarnings('ignore')

from ultralytics import YOLO

if __name__ == '__main__':
    print("Starting script...")

    # 主干 yolov8-MobileNetv4.yaml
    # 注意力  yolov8-MLCA.yaml  yolov8-MobileNetv4-MLCA.yaml
    # 检测头 yolov8-AFPN.yaml  yolov8-MobileNetv4-AFPN.yaml
    # 主干+注意力+检测头 yolov8-MMA.yaml

    # model = RTDETR(model='ultralytics/cfg/models/rt-detr/rt-detr-test.yaml')
    print("Loading model...")
    # model = YOLO('ultralytics/cfg/models/v8/yolov8-HGNet1.yaml').load('yolov8n.pt')
    model = YOLO('ultralytics/cfg/models/v8/yolov8.yaml').load('yolov8n.pt')

    print("Training model...")
    model.train(
        data='ultralytics/cfg/data.yaml',
        cache=False,
        imgsz=640,
        epochs=200,
        batch=16,
        workers=8,
        device='0,1',  # Corrected device specification
        optimizer='SGD',  # Using SGD
        amp=False,  # Close AMP to avoid precision errors
        project='runs/train',
        name='exp',
    )

    print("Exporting model to ONNX...")
    # Export the trained model to ONNX format after training
    model.export(format='onnx')  # dynamic=True

    print("Script completed.")